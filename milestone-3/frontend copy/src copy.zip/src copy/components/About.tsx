import React from "react";
//import "./navbar.css";

export default function About() {
  return (
    // replace everything in between the <header> & <header /> tags
    // with your navbar code from your earlier milestones
         
    /* <RecipePreview name={recipeData[0].name} image={recipeData[0].image} desc={recipeData[0].description}/> */
    <main>
      <h2> My Cooking knowledge </h2>
        <a href = "https://www.coolmathgames.com/0-coffee-shop">Cool Math Games: Coffee Shop</a> 
    </main>
  );
}